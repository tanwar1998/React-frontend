import React from "react";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    // withRouter
} from "react-router-dom";

import PageNotFound from './pages/PageNotFound';
import User from "./pages/User/containers";
import Vhicle from "./pages/Vhicle/containers";
import Mvc from "./pages/Mvc/containers";

export default function App() {
    return (
        <Router>
            <Switch>
                <Route exact path="/user" component={User}  />
                <Route exact path="/" component={User}  />
                <Route exact path="/vhicle" component={Vhicle}  />
                <Route exact path="/mvc" component={Mvc}  />
                <Route path="*" component={PageNotFound}/>
            </Switch>
        </Router>
    );
}

