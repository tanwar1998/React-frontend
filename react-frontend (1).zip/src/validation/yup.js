import * as yup from 'yup';

const otp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?$/
export const validationSchemaReg = yup.object().shape({
    name: yup
      .string()
      .required("Name is required"),
    email: yup
      .string()
      .email("Email is not valid")
      .required("Email is required"),
    password: yup
     .string()
     .min(8,"Password must be minimum 8 characters long")
     .required("Password is required"),
 });

 export const validationSchemaLogin = yup.object().shape({
  email: yup
    .string()
    .email("Email is not valid")
    .required("Email is required"),
  firstName: yup
   .string()
   .required("First Name is required"),
  lastName: yup
   .string()
   .required("Last Name is required"),
   
  phone: yup
  .string()
  .required("Phone Number is required"),
});


export const validationVhicle = yup.object().shape({
  make: yup
    .string()
    .required("Make is required"),
  odometer: yup
   .string()
   .required("Odometer is required"),
  vin: yup
   .string()
   .required("VIN is required"),
   
  model: yup
  .string()
  .required("Model is required"),
});


export const validationSchemaResetPassword = yup.object().shape({
  password: yup
   .string()
   .min(8,"Password must be minimum 8 characters long")
   .required("Password is required"),
  repeatPassword: yup
   .string()
   .min(8,"Password must be minimum 8 characters long")
   .required("Password is required")
   .oneOf([yup.ref('password'), null], 'Passwords must match'),
});

export const validationSchemaRecoverPassword = yup.object().shape({
  email: yup
    .string()
    .email("Email is not valid")
    .required("Email is required"),
});

 export const validationSchemaAdd = yup.object().shape({
  phone: yup
    .string().matches(otp, 'Phone number is not valid')
    .max(10,"Phone must be minimum 10 characters long")
    .min(10,"Phone must be maximum 10 characters long")
    .required("Phone is required"),
    email: yup
    .string()
    .email("Email is not valid")
    .required("Email is required"),
  password: yup
   .string()
   .min(8,"Password must be minimum 8 characters long")
   .required("Password is required"),
  confirmpassword: yup
   .string()
   .required("Password is required")
   .oneOf(
   [yup.ref('password'), null],
    'Passwords must match',
  ),
});

export const validationSchemaOtp = yup.object().shape({
  otp: yup
    .string().matches(otp, 'OTP number is not valid')
    .max(4,"OTP must be minimum 4 characters long")
    .min(4,"OTP must be maximum 4 characters long")
    .required("OTP is required"),
 })

export const validationSchemaBussiness = yup.object().shape({
  websiteName: yup
      .string()
      .required("Website name is required"),
  websiteAddress: yup
     .string()
     .required("Website address is required"),
  visitorsList: yup
     .string()
     .required("Visitor is required"),
  cms: yup
    .string()
    .required("CMS is required"),
  aboutUs: yup
      .string()
      .required("About us is required"),  
 })

 export const validationSchemaWebsiteDetail = yup.object().shape({
  name: yup
      .string()
      .required("Website name is required"),
  address: yup
     .string()
     .required("Website address is required"),
  category: yup
     .string()
     .required("Website category is required"),
  platform_name: yup
    .string()
    .required("Website platform is required"),
  others: yup
    .string()
 })

 export const validationSchemaCreateTag = yup.object().shape({
  tagName: yup
      .string()
      .required("Tag name is required"),
  applyArticle: yup
     .string()
     .required("Apply article is required"),
  url: yup
     .string()
     .required("URL is required"),
  customPlayer: yup
    .string()
    .required("Custom player is required"),
  voiceProfile1: yup
     .string()
     .required("Voice Profile1 is required"),
  voiceProfile2: yup
    .string()
    .required("Voice Profile1 is required"),
 })

 export const validationSchemaGeneralSetting = yup.object().shape({
  tagName: yup
      .string()
      .required("Tag name is required"),
      siteUrl: yup
     .string()
     .required("Site name is required"),
     siteDes: yup
     .string()
     .required("Site description is required"),
     siteLanguage: yup
    .string()
    .required("Site language is required"),
    siteCategory: yup
     .string()
     .required("Site category is required")
 })

 export const validationSchemaProfile = yup.object().shape({
name: yup
      .string()
      .required("Tag name is required"),
email: yup
    .string()
    .email("Email is not valid")
    .required("Email is required"),
password: yup
   .string()
   .min(8,"Password must be minimum 8 characters long")
   .required("Password is required"),
newPassword: yup
   .string()
   .min(8,"Password must be minimum 8 characters long")
   .required("Password is required"),
site: yup
     .string()
     .required("Site category is required")
 })