import { contructGenericGETAction } from "./blueprint"

export const get_apps = () => {
  return contructGenericGETAction("APPS_LIST", "/v1/user/sites/")(JSON.stringify())
};

export const set_current_app = (data) => {
  return {
    type : 'CURRENT_APP_SUCCESS',
    payload : {...data.current_app}
  }
};