// import { contructGenericPOSTAction,contructGenericPUTAction } from "./blueprint"
import { contructGenericPOSTAction } from "./blueprint"
import axios from 'axios';
import { apiUrl } from '../../config/environments/development';


// export const verifyOtp = (body) => {
//   return contructGenericPUTAction("VERIFY_OTP", "/v1/user/")(JSON.stringify(body))
// };

// here starts my api calls
export const registerBuyer = (body) => {
  const req = {
    'purpose':'registerUser',
    'data': body
  }
  return axios.post('https://vxts44ce03.execute-api.us-east-2.amazonaws.com/register', req);
  // const result = await axios.post('https://vxts44ce03.execute-api.us-east-2.amazonaws.com/register', req);
  // return result;
  // return contructGenericPOSTAction("registerBuyer", "/registerBuyer")(JSON.stringify(req))
}
// https://vxts44ce03.execute-api.us-east-2.amazonaws.com/register

export const registerSeller = (body) => {
  return contructGenericPOSTAction("registerSeller", "/registerBuyer")(JSON.stringify(body))
}

export const getAllVhicles = async() => {
  // return contructGenericGETAction("getAllVhicles", "/getAllVhicles")(JSON.stringify())
  const result = await axios.get(apiUrl+'/getAllVhicles');
  return result;
}

export const changeOwnership = async(data) => {
  const result = await axios.post(apiUrl+'/changeOwnership', data);
  return result;
}