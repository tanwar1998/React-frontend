import { apiUrl } from '../../config/environments/development';
import { getAuthToken } from './token';

const apiWrapper = async (
	method,
	url,
	body,
	queryParams = {},
	mainUrl = apiUrl,
	// file,
) => {
	const token = getAuthToken();

	const headers = {
		Accept: 'application/json',
		'Content-Type': 'application/json'
	};
	if (token) {
		headers.Authorization = `Bearer ${token}`;
	}
	// if (file){

	// }

	// let query = Object.keys(queryParams)
	// 	.map(q => encodeURIComponent(q) + '=' + encodeURIComponent(queryParams[q]))
	// 	.join('&');

	//let finalURL = `${mainUrl}${url}?${query}`;
	let finalURL = `${mainUrl}${url}`;
	try {
		let response = await fetch(finalURL, {
			method,
			headers,
			body
		});
			
		let formattedResponse = await response.json();
		
		if (response.ok === false) {
			throw formattedResponse;
		}
		console.log(finalURL, method, body, formattedResponse);
		return formattedResponse;
	} catch (e) {
		console.log(finalURL, method, body, e);
		throw e;
	}
};

let API = {
	GET: (path, queryParams) => apiWrapper('GET', path, null, queryParams),
	POST: (path, body) => apiWrapper('POST', path, body),
	PUT: (path, body) => apiWrapper('PUT', path, body)
};

export default API;
