// token will be stored directly in the string format

let tokenKey = 'token';
let cred= 'cred'
let userDetails = 'userDetails'

export const removeAuthToken = () => {
  localStorage.removeItem(tokenKey)
}

export const getAuthToken = () => {
  return localStorage.getItem(tokenKey)
}

export const setAuthToken = (value) => {
  return localStorage.setItem(tokenKey, value)
}

export const removeCred = () => {
  localStorage.removeItem(cred)
}

export const getCred = () => {
  return JSON.parse(localStorage.getItem(cred))
}

export const setCred = (value) => {
  return localStorage.setItem(cred, JSON.stringify(value))
}

export const removeUserObject = () => {
  localStorage.removeItem(userDetails)
}

export const getUserObject = () => {
  return JSON.parse(localStorage.getItem(userDetails))
}

export const setUserObject = (value) => {
  return localStorage.setItem(userDetails, JSON.stringify(value))
}