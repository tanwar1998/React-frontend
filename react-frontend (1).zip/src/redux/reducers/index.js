import { connectRouter } from "connected-react-router";
import { combineReducers } from "redux";
import authReducer from './authReducer';
import loggedInfoReducer from './loggedInfoReducer';
import registrationReducer from './registrationReducer';
import userMeReducer from './loggedInfoReducer';
import currentAppReducer from './currentAppReducer';

export default history => {
  return combineReducers({
    router: connectRouter(history),
    authReducer,
    loggedInfoReducer,
    registrationReducer,
    userMeReducer,
    currentAppReducer
  });
};