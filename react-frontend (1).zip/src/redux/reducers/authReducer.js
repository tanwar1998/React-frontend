import { setAuthToken } from "../api/token"

const initialState = {
    status: 'notauthenticated',
    isSigendIn: false,
    authToken:''
}

const authReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'LOGIN_REQUEST':
            return {
                isSignedIn: false,
                status: 'authenticating'
            }
        case 'LOGIN_SUCCESS':
            setAuthToken(action.payload);
            return {
                isSignedIn: true,
                authToken: action.payload,
                status: 'authenticated',
            }
        case 'LOGIN_FAILURE':
            return {
                isSignedIn: initialState.isSigendIn,
                authToken: action.payload,
                status: initialState.status
            }
        default:
            return state
    }
}

export default authReducer;

