import { setUserObject } from "../api/token"

const initialState = {
    status: false,
    user_details:{},
    error : {}
}

const loggedInfoReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'USER_DETAILS_REQUEST':
            return {
                status: false,
            }
        case 'USER_DETAILS_SUCCESS':
            setUserObject(action.payload);
            return {
                status: true,
                user_details: action.payload,
            }
        case 'USER_DETAILS_FAILURE':
            return {
                status: false,
                error: action.error,
            }
        default:
            return state
    }
}

export default loggedInfoReducer;

