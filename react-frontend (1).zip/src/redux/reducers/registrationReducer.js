const initialState = {
    logedInInfo:{},
    status:null
}

const registrationReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADDED_USER_REQUEST':
            return {
                status: null
            }
        case 'ADDED_USER_SUCCESS':
            return {
                status: 'success',
                loggedInInfo: action.payload,
            }
        case 'ADDED_USER_FAILURE':
            return {
                status: null,
            }
        default:
            return state            
    }
}

export default registrationReducer;