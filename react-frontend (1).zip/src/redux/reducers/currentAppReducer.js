// import { setUserObject } from "../api/token"

const initialState = {
    status: false,
    user_details:{},
}

const currentAppReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'CURRENT_APP_REQUEST':
            return {
                status: false,
            }
        case 'CURRENT_APP_SUCCESS':
            console.log('action.payload')
            console.log(action.payload)
            return {
                status: true,
                current_app_detail: action.payload,
            }
        case 'CURRENT_APP_FAILURE':
            return {
                status: false,
                error: action.error,
            }
        default:
            return state
    }
}

export default currentAppReducer;