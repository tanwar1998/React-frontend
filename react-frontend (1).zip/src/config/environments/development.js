export const apiUrl = 'http://localhost:4000'
export const playerUrl = 'http://localhost:4000'
