import styled from 'styled-components'

export const FormHeader = styled.div`
.header-form {
    display: flex;
    justify-content: space-between;
    padding: 20px 80px;
    align-items: center;
    border: 1px solid #DEDEDE;
  }
  
  .header-border {
    border-bottom: 1px solid #DEDEDE;
  }
  
  @media screen and (max-width: 767px){
    .header-form {
      flex-direction: column;
      display: none;
    }
  }

  .contact-sales, .otpClass {
    background: #FFFFFF 0% 0% no-repeat padding-box;
    border-radius: 2px;
    opacity: 1;
    text-align: center;
    letter-spacing: 0.32px;
    opacity: 1;
    padding: 7px 15px;
  }
  
  .otpClass {
    color: #0080FF;
    border: 2px solid #0080FF;
  }

  .contact-sales {
    color: #B083FF;
    border: 2px solid #B083FF;
  }
  
  .sub-header {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .sub-header img {
    width: 38px;
  }

  .sub-header h2 {
    font-weight: bold;
    letter-spacing: 0.12px;
  }
`