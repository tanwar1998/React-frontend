import React, { Component } from 'react'
import * as style from './style'

// import Logo from '../../assets/images/formImages/logo.png'

class FormHeader extends Component {
    render() {
        // const { otp, login, register, site } = this.props
        return (
            <style.FormHeader>
                <div className="header-form">
                    <div className="sub-header">
                        {/* <img src={Logo} alt="logo" /> */}
                        <h2 className="h4 mt-2 ml-2" style={{color: "#000000"}}><b>Susurla</b></h2>
                    </div>
                    <div>
                        {/* <a href="#" className={`${ otp || register || site ? 'otpClass' : 'contact-sales'} ${login ? 'd-none' : 'd-block'}`}>Contact Sales</a> */}
                    </div>
                </div>
            </style.FormHeader>
        )
    }
}

export default FormHeader
