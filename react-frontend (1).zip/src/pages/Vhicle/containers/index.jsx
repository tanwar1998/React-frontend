import React, { Component } from "react";
import Vhicle from "../components";
import FormHeader from "../../../Components/FormHeader/formHeader";
import { connect } from "react-redux";
import { toast } from "react-toastify";
import axios from 'axios';
import { apiUrl } from '../../../config/environments/development';

class VhicleContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      values: {
        model: "",
        vin: "",
        odometer: "",
        make: "",
      },
      isSubmitting: false,
      fileName:'',
      fileNameError: false
    };
  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.files[0] });
  };
   fileData = {
     'file':''
   }

  onChangeHandler = (event) => {
    event.preventDefault();
    let setValue = {
      values: {file: event.target.files[0].name}
    }
    this.setState(setValue);
    this.fileData.file = event.target.files[0];
  };

  handleSubmit = async (values) => {
    try {

      if(this.fileData.file == ''){
        this.setState({fileNameError: true});
        return false;
      }

      let data = new FormData()
      data.append('file', this.fileData.file);
      data.append('make', values.make);
      data.append('vin', values.vin);
      data.append('odometer', values.odometer);
      data.append('userId', '5f3560c23c074d1668cccfbf');
      data.append('model', values.model);
      axios({
        method: 'post',
        url: apiUrl+'/registerVhicle',
        data: data,
        headers:{ 'Content-Type':'multipart/form-data' }
      }).then(res => { // then print response status
        console.log(res)
      })

    } catch (error) {
      toast.error(error.message);
      console.log(error);
    }
  };

  render() {
    return (
      <div>
        <FormHeader login="true" />
        <Vhicle
          values={this.state.values}
          handleSubmit={this.handleSubmit}
          onChangeHandler={this.onChangeHandler}
          isSubmitting={this.state.isSubmitting}
          fileName={this.state.fileName}
          fileNameError={this.state.fileNameError}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    state,
  };
};

const dispatchStateToProps = (dispatch) => {
  // return {
  //   registerVhicle: (data) => dispatch(registerVhicle(data)),
  // };
  return null;
};

export default connect(mapStateToProps, dispatchStateToProps)(VhicleContainer);
