import React from "react";
import { Formik, Field, ErrorMessage } from "formik";
import { validationVhicle } from "../../../validation/yup";
import * as style from "../style";

const validationSchema = validationVhicle;

class Vhicle extends React.Component {
  renderForm = () => {
    return (
      <div className="container h-100 font-family-M">
        <div className="d-flex justify-content-center h-100">
          <div className="user_card">
            <div className="form-container">
              <div className="text-center mb-5 mt-4">
                <div className="text-center">
                  <h1 className="h3 pl-2 pr-2 pb-0 text-light-black">
                    <b>Vhicle Details</b>
                  </h1>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-12">
                  <Formik
                    initialValues={this.props.values}
                    validationSchema={validationSchema}
                    onSubmit={this.props.handleSubmit}
                  >
                    {({ handleSubmit,touched, errors, isSubmitting, fileName }) => (
                      <style.LoginForm>
                        <div className="form-group">
                          <Field
                            type="text"
                            name="make"
                            placeholder="Make"
                            className={`form-control form-control-user ${
                              touched.make && errors.make ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="make"
                            className="invalid-feedback"
                          />
                        </div>
                        <div className="form-group">
                          <Field
                            type="text"
                            name="model"
                            placeholder="Model"
                            className={`form-control form-control-user ${
                              touched.model && errors.model ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="model"
                            className="invalid-feedback"
                          />
                        </div>
                        
                        <div className="form-group">
                          <Field
                            type="text"
                            name="vin"
                            placeholder="VIN"
                            className={`form-control form-control-user ${
                              touched.vin && errors.vin ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="vin"
                            className="invalid-feedback"
                          />
                        </div>
                        
                        <div className="form-group">
                          <Field
                            type="text"
                            name="odometer"
                            placeholder="Odometer"
                            className={`form-control form-control-user ${
                              touched.odometer && errors.odometer ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="odometer"
                            className="invalid-feedback"
                          />
                        </div>
                        
                        <div className="form-group">
                          <Field
                            type="file"
                            name="file"
                            placeholder="Input File"
                            onChange={this.props.onChangeHandler}
                            className={`form-control form-control-user ${
                              touched.file && errors.file ? "is-invalid" : ""
                            }${this.props.fileNameError? "is-invalid": ""}`}
                          />
                          <ErrorMessage
                            component="div"
                            name="file"
                            className="invalid-feedback"
                          />
                        </div>
                        <div>
                          {  this.props.fileName ? this.props.fileName.toString() : '' }
                          { touched.file }
                        </div>

                        <div className="login_container">
                          <button
                            type="submit"
                            className="btn btn-primary btn-user btn-block"
                            onClick={handleSubmit}
                            disabled={this.props.isSubmitting}
                          >
                            {isSubmitting ? "Please wait..." : "save"}
                          </button>
                        </div>
                      </style.LoginForm>
                    )}
                  </Formik>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    return this.renderForm();
  }
}
export default Vhicle;
