import React, { Component } from "react";
import User from "../components";
import FormHeader from "../../../Components/FormHeader/formHeader";
import { registerBuyer } from "src/redux/actions/user.actions";
import { connect } from "react-redux";
import axios from 'axios';
import { toast } from "react-toastify";
// import {removeAuthToken,removeCred,removeUserObject} from 'src/redux/api/token'

class UserContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      values: {
        email: "",
        firstName: "",
        lastName: "",
        phone: "",
      },
      isSubmitting: false,
    };
  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleSubmit = async (value) => {
    try {
      console.log('handle submit called  ', value);
      // const buyerResponse = await this.props.registerBuyer(value);

      const req = {
        'purpose':'registerUser',
        'data': value
      }
      // return axios.post('https://vxts44ce03.execute-api.us-east-2.amazonaws.com/register', req);

      axios({
        method: 'post',
        // url: 'https://tqjir6aw96.execute-api.us-east-2.amazonaws.com/Dev',
        url: 'https://vxts44ce03.execute-api.us-east-2.amazonaws.com/register',
        data: req,
        // headers:{ 'Content-Type':'multipart/form-data' }
      }).then(res => { // then print response status
        console.log(res)
      })

    // } catch (error) {
    //   toast.error(error.message);
    //   console.log(error);
    // }


      // console.log('buyerResponse', buyerResponse);
    } catch (error) {
      toast.error(error.message);
      console.log(error);
    }
  };

  render() {
    return (
      <div>
        <FormHeader login="true" />
        <User
          values={this.state.values}
          handleSubmit={this.handleSubmit}
          isSubmitting={this.state.isSubmitting}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    state,
  };
};

const dispatchStateToProps = (dispatch) => {
  return {
    registerBuyer: (data) => dispatch(registerBuyer(data)),
  };
};

export default connect(mapStateToProps, dispatchStateToProps)(UserContainer);
