import React from "react";
import { Formik, Field, ErrorMessage } from "formik";
import { validationSchemaLogin } from "../../../validation/yup";
import * as style from "../style";

const validationSchema = validationSchemaLogin;

class User extends React.Component {
  renderForm = () => {
    return (
      <div className="container h-100 font-family-M">
        <div className="d-flex justify-content-center h-100">
          <div className="user_card">
            <div className="form-container">
              <div className="text-center mb-5 mt-4">
                <div className="text-center">
                  <h1 className="h3 pl-2 pr-2 pb-0 text-light-black">
                    <b>User Details</b>
                  </h1>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-12">
                  <Formik
                    initialValues={this.props.values}
                    validationSchema={validationSchema}
                    onSubmit={this.props.handleSubmit}
                  >
                    {({ handleSubmit,touched, errors, isSubmitting }) => (
                      <style.LoginForm>
                        <div className="form-group">
                          <Field
                            type="text"
                            name="firstName"
                            placeholder="First Name"
                            className={`form-control form-control-user ${
                              touched.firstName && errors.firstName ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="firstName"
                            className="invalid-feedback"
                          />
                        </div>
                        <div className="form-group">
                          <Field
                            type="text"
                            name="lastName"
                            placeholder="Last Name"
                            className={`form-control form-control-user ${
                              touched.lastName && errors.lastName ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="lastName"
                            className="invalid-feedback"
                          />
                        </div>
                        
                        <div className="form-group">
                          <Field
                            type="text"
                            name="email"
                            placeholder="Email Address"
                            className={`form-control form-control-user ${
                              touched.email && errors.email ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="email"
                            className="invalid-feedback"
                          />
                        </div>
                        
                        <div className="form-group">
                          <Field
                            type="text"
                            name="phone"
                            placeholder="Phone Number"
                            className={`form-control form-control-user ${
                              touched.phone && errors.phone ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            component="div"
                            name="phone"
                            className="invalid-feedback"
                          />
                        </div>

                        <div className="login_container">
                          <button
                            type="submit"
                            className="btn btn-primary btn-user btn-block"
                            onClick={handleSubmit}
                            disabled={this.props.isSubmitting}
                          >
                            {isSubmitting ? "Please wait..." : "save"}
                          </button>
                        </div>
                      </style.LoginForm>
                    )}
                  </Formik>
                </div>
              </div>
              <hr className="sign-up"></hr>
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    return this.renderForm();
  }
}
export default User;
