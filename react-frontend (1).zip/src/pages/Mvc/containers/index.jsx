import React, { Component } from "react";
import Mvc from "../components";
import FormHeader from "../../../Components/FormHeader/formHeader";
import { registerBuyer, changeOwnership } from "src/redux/actions/user.actions";
import { connect } from "react-redux";
import { toast } from "react-toastify";


class MvcContainer extends Component {
  constructor(props) {
    super(props);
    // (async () => {
      // this.getAllVhicles();
    // })
    
    this.state = {
      vhicleList: null      
    };
  }
  async componentDidMount(){
    console.log('before getvhicle')
    await this.getAllVhicles();
    console.log('after getvhicle')
  }
  // async init(){
  //   console.log('init function')
  //   await this.getAllVhicles();
  // }

  getAllVhicles = async () => {
    let list = await this.props.getAllVhiclesList();
    if( list.data.success ){
      this.setState({ vhicleList: list.data.data });
    }

  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleChange = async (value) => {
    try {
      console.log('handle submit called  ', value);
      const changeOwnershiptResponse = await this.props.changeOwnership(value);
      console.log('ChangeOwnershipt', changeOwnershiptResponse);
    } catch (error) {
      toast.error(error.message);
      console.log(error);
    }
  };

   render(){
    // await this.getAllVhicles();
    return (
      <div>
        <FormHeader login="false" />
        <Mvc
          vhicleList={ this.state.vhicleList }
          handleChange={this.handleChange}
          // isSubmitting={this.state.isSubmitting}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    state,
  };
};

const dispatchStateToProps = (dispatch) => {
  return {
    changeOwnership: async() => await changeOwnership(),
  };
};

export default connect(mapStateToProps, dispatchStateToProps)(MvcContainer);
