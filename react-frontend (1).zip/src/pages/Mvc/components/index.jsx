import React from "react";
// import * as style from "../style";
import { Table, Button } from 'react-bootstrap';

class Mvc extends React.Component {

  getTableRow = (data, index) => {
    return (
      <tr key = {index}>
      <td>{index}</td>
      <td>{data.seller}</td>
      <td>{data.buyer}</td>
      <td>{data.VIN}</td>
      <td>
        <Button variant="info" onClick={ () => { this.props.handleChange(data) }  }>Change</Button>
      </td>
    </tr>
    )
  }
  
  renderTable = () => {
    if(this.props.vhicleList === null){
      return null;
    }

    let length = this.props.vhicleList.length;
    let row = [];
    for(let i=0; i < length; i++){
      row.push(this.getTableRow(this.props.vhicleList[i], (i+1)))
    }
    return row;
  }

  renderForm = () => {
    return (
      <div className="container h-100 font-family-M">
        <div className="d-flex justify-content-center h-100">
          <div className="user_card">
            <div className="form-container">
              <div className="text-center mb-5 mt-4">
                <div className="text-center">
                  <h1 className="h3 pl-2 pr-2 pb-0 text-light-black">
                    <b>MVC Controller</b>
                  </h1>
                </div>
              </div>

            </div>
          </div>

         

        </div>

        <div className="md">
          <Table striped bordered hover responsive="md">
            <thead>
              <tr>
                <th>#</th>
                <th>Seller</th>
                <th>Buyer</th>
                <th>VIN</th>
                <th>Change Ownership</th>
              </tr>
            </thead>
            <tbody>
              { this.renderTable() }
            </tbody>
          </Table>
        </div>
      </div>
      
    );
  };

  render() {
    return this.renderForm();
  }
}
export default Mvc;
